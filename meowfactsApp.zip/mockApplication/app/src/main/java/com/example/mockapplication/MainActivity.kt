package com.example.mockapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {
    // the url to the "MeowFacts"
    // change number to vary amount of cat facts
    private val urlAddress = "https://meowfacts.herokuapp.com/?count=15"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val getButton: Button = findViewById(R.id.getButton)
        getButton.setOnClickListener {
            sendGetRequest(urlAddress)
        }
        // exit app button
        val closeButton: Button = findViewById(R.id.closeButton)
        closeButton.setOnClickListener { finish();exitProcess(0);
        }
    }

    private fun sendGetRequest(urlString: String) {
        CoroutineScope(Dispatchers.IO).launch {
            val result = try {
                val url = URL(urlString)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.inputStream.bufferedReader().use { it.readText() }
            } catch (e: Exception) {    // error handling for debugging
                e.printStackTrace()
                "Error: ${e.message}"
            }

            withContext(Dispatchers.Main) {
                try {
                    // parsing the JSON file received from GET request
                    // then pushing the parsed data into facts array list: "facts", this is used later to populate the list view
                    val jsonObject = JSONObject(result)
                    val dataArray = jsonObject.getJSONArray("data")
                    val facts = ArrayList<String>()
                    for (i in 0 until dataArray.length()) { // run through JSON until every line has been picked up
                        facts.add(dataArray.getString(i))
                    }
                    val intent = Intent(this@MainActivity, ListActivity::class.java).apply {
                        // inflate the array created above into new activity
                        putStringArrayListExtra("facts", facts)
                    }
                    startActivity(intent)
                } catch (e: Exception) {    // error handlingfor debugging
                    e.printStackTrace()
                }
            }
        }
    }
}

