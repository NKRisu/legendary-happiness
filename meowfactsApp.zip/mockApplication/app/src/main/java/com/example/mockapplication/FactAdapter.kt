package com.example.mockapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class FactAdapter(private val context: Context, private val facts: List<String>) : BaseAdapter() {
    // fact amount
    override fun getCount(): Int {
        return facts.size
    }
    // fact index
    override fun getItem(position: Int): Any {
        return facts[position]
    }
    // fact id
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }
    // connecting the view, text and inflating it with kitty facts
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(context).inflate(R.layout.list_item, parent, false)
        val factLabel: TextView = view.findViewById(R.id.factLabel)
        val factText: TextView = view.findViewById(R.id.factText)

        factLabel.text = "Fact ${position + 1}"
        factText.text = facts[position]

        return view
    }
}
