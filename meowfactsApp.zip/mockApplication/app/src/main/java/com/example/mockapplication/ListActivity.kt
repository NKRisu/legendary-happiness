package com.example.mockapplication

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentTransaction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL


class ListActivity : AppCompatActivity() {
    // the same url here, should probably link the two activities but eh... it's fine for now
    private val urlAddress = "https://meowfacts.herokuapp.com/?count=15"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        // setup list view and facts
        val listView: ListView = findViewById(R.id.responseList)
        val facts = intent.getStringArrayListExtra("facts")
        // fill list if facts are in GET response
        if (facts != null) {
            val adapter = FactAdapter(this, facts)
            listView.adapter = adapter
        }
        // go back to main button
        val backButton: Button = findViewById(R.id.backButton)
        backButton.setOnClickListener {
            finish()
        }
        // button to refresh the list view, button press listener to send URL to function
        val getButton: Button = findViewById(R.id.refreshButton)
        getButton.setOnClickListener {
            sendGetRequest(urlAddress, listView)
        }
        // button to go to google search for extra points
        val searchButton: Button = findViewById(R.id.searchButton)
        searchButton.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=fun+cat+facts")))   // URL to search, edit this if you want another site to open
        }
        // opening fragment when clicking on any of the facts listed, position saved and this is used in the fragment
        listView.setOnItemClickListener { _, _, position, _ ->
            val fragment = FactFragment.newInstance(position + 1)   // +1 because index starts from zero
            val transaction: FragmentTransaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragmentContainer, fragment)
            transaction.addToBackStack(null)
            transaction.commit()
        }
        // trying to let user close the fragment via tapping anywhere on screen.
        // it sort of works, user just needs to tap *not on the list or buttons* which is rather difficult at times
        // so the usable "close the fragment"-area is quite small
        // this is also deprecated code but it works
        val rootView: View = findViewById(android.R.id.content)
        rootView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val fragment = supportFragmentManager.findFragmentById(R.id.fragmentContainer)
                if (fragment != null && fragment.isVisible) {
                    supportFragmentManager.beginTransaction().remove(fragment).commit()
                }
            }
            true
        }
    }
    // function that sends the request, 2 things needed, url and return message, still doesn't like hardcoded URL
    private fun sendGetRequest(urlString: String, listView: ListView) {
        CoroutineScope(Dispatchers.IO).launch {
            val result = try {
                val url = URL(urlString)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.inputStream.bufferedReader().use { it.readText() }
            } catch (e: Exception) {
                e.printStackTrace()
                "Error: ${e.message}"
            }
            withContext(Dispatchers.Main) {
                try {
                    val jsonObject = JSONObject(result)
                    val dataArray = jsonObject.getJSONArray("data")
                    val facts = ArrayList<String>()
                    for (i in 0 until dataArray.length()) {
                        facts.add(dataArray.getString(i))
                    }
                    val adapter = FactAdapter(this@ListActivity, facts)
                    listView.adapter = adapter
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}
