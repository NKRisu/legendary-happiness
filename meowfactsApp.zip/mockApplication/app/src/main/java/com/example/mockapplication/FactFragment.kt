package com.example.mockapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class FactFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_fact, container, false)
        val factNumber = arguments?.getInt("factNumber") ?: 0
        val textView: TextView = view.findViewById(R.id.factNumberText)
        textView.text = "Fact Number: $factNumber from: meowfacts"  // text that is displayed
        return view
    }
    // creates the instance of factNumber fragment
    companion object {
        fun newInstance(factNumber: Int): FactFragment {
            val fragment = FactFragment()
            val args = Bundle()
            args.putInt("factNumber", factNumber)
            fragment.arguments = args
            return fragment
        }
    }
}
